import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class ConnectionFactory {
    private static final String Username = "root";
    private static final String Password = "";
    private static final String url = "jdbc:mysql://localhost:3306/iiits";

    public static Connection getConnection() {
        Connection con = null;
        try {
            Properties connectionProperties = new Properties();
            connectionProperties.put("user", Username);
            connectionProperties.put("password", Password);
            con = DriverManager.getConnection(url, connectionProperties);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return con;
    }
}
