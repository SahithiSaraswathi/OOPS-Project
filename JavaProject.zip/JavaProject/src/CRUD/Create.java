package CRUD;
import Main_Connection.*;

import laptop.Laptop;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Create {
    public static void createLaptop(Laptop lp) {
        Connection con = ConnectionFactory.getConnection();
        final String SQL = "insert into laptop values(?,?,?,?)";
        try (PreparedStatement stm = con.prepareStatement(SQL)) {
            stm.setInt(1, lp.getId());
            stm.setString(2, lp.getName());
            stm.setInt(3, lp.getPrice());
            stm.setString(4, lp.getAvailability());
            int rows_affected = stm.executeUpdate();
            System.out.println(" number of rows created are ." + rows_affected);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
