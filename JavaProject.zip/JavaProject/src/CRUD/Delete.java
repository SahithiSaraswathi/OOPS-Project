package CRUD;
import Main_Connection.*;
import laptop.Laptop;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class Delete {
    public static void updateLaptop(Laptop lp) {
        Connection con = ConnectionFactory.getConnection();
        final String SQL = "update laptop set name=?, price=?,availability=? where id=?";
        try (PreparedStatement stm = con.prepareStatement(SQL)) {
            stm.setInt(4, lp.getId());
            stm.setString(1, lp.getName());
            stm.setInt(2, lp.getPrice());
            stm.setString(3, lp.getAvailability());
            int rows_affected = stm.executeUpdate();
            System.out.println(" number of rows uppdated are ." + rows_affected);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteLaptop(int id) {
        Connection con = ConnectionFactory.getConnection();
        final String SQL = "delete from laptop where id = ?";
        try (PreparedStatement stm = con.prepareStatement(SQL)) {
            stm.setInt(1, id);
            int rows_affected = stm.executeUpdate();
            System.out.println(" number of rows deleted are ." + rows_affected);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteLaptop(String name) {
        Connection con = ConnectionFactory.getConnection();
        final String SQL = "delete from laptop where name= ?";
        try (PreparedStatement stm = con.prepareStatement(SQL)) {
            stm.setString(1, name);
            int rows_affected = stm.executeUpdate();
            System.out.println(" number of rows deleted are ." + rows_affected);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void DeleteAll() {
        Connection con = ConnectionFactory.getConnection();
        final String SQL = "truncate table laptop;";
        try (PreparedStatement stm = con.prepareStatement(SQL)) {
            stm.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
