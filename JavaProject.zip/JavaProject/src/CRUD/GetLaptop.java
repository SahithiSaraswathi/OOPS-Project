package CRUD;


import Main_Connection.*;
import laptop.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class GetLaptop {

    public static List<Laptop> getAllLaptops() {
        List<Laptop> laptops = new ArrayList<>();
        Connection con = ConnectionFactory.getConnection();
        final String SQL = "select * from laptop";
        try (PreparedStatement stm = con.prepareStatement(SQL)) {
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Laptop lp = new Laptop(rs.getInt("id"), rs.getString("name"), rs.getInt("price"),
                        rs.getString("Availability"));
                laptops.add(lp);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return laptops;
    }

    public static List<Laptop> getLaptop(int id) {
        List<Laptop> laptops = new ArrayList<>();
        Connection con = ConnectionFactory.getConnection();
        final String SQL = "select * from laptop where id = ?";
        try (PreparedStatement stm = con.prepareStatement(SQL)) {
            stm.setInt(1, id);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Laptop lp = new Laptop(rs.getInt("id"), rs.getString("name"), rs.getInt("price"),
                        rs.getString("availability"));
                laptops.add(lp);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println(laptops.size() + " rows found");
        return laptops;
    }

    public static List<Laptop> getLaptop(String name) {
        List<Laptop> laptops = new ArrayList<>();
        Connection con = ConnectionFactory.getConnection();
        final String SQL = "select * from laptop where name = ?";
        try (PreparedStatement stm = con.prepareStatement(SQL)) {
            stm.setString(1, name);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Laptop lp = new Laptop(rs.getInt("id"), rs.getString("name"), rs.getInt("price"),
                        rs.getString("availability"));
                laptops.add(lp);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println(laptops.size() + " rows found");
        return laptops;
    }

    public static List<Laptop> getbyAvailability() {
        List<Laptop> laptops = new ArrayList<>();
        Connection con = ConnectionFactory.getConnection();
        final String SQL = "select * from laptop where availability = ?";
        try (PreparedStatement stm = con.prepareStatement(SQL)) {
            stm.setString(1, "yes");
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Laptop lp = new Laptop(rs.getInt("id"), rs.getString("name"), rs.getInt("price"),
                        rs.getString("availability"));
                laptops.add(lp);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println(laptops.size() + " laptops found in available");
        return laptops;
    }

    public static List<Laptop> getLaptopByprice(int price) {
        List<Laptop> laptops = new ArrayList<>();
        Connection con = ConnectionFactory.getConnection();
        final String SQL = "select * from laptop where price=?";
        try (PreparedStatement stm = con.prepareStatement(SQL)) {
            stm.setInt(1, price);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Laptop lp = new Laptop(rs.getInt("id"), rs.getString("name"), rs.getInt("price"),
                        rs.getString("availability"));
                laptops.add(lp);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println(laptops.size() + " laptops found for this price");
        return laptops;
    }

}
