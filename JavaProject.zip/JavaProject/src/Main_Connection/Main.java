package Main_Connection;

import CRUD.*;
import java.io.*;
import java.util.List;
import laptop.Laptop;

public class Main {
    public static void help() {
        System.out.println("--------------------Commands for Mini Project---------------------");
        System.out.println(" LOAD CSV               : -load");
        System.out.println(" CREATE LAPTOP          : -create id name price availability");
        System.out.println(" PRINT All              : -printAll  ");
        System.out.println(" UPDATE BY  ID          : -update id name price availability ");
        System.out.println(" DELETE BY  ID          : -delete_id id");
        System.out.println(" DELETE BY  NAME        : -delete_name name");
        System.out.println(" DELETE ALL (Truncate)  : -truncate");
        System.out.println(" SEARCH BY NAME         : -gtLaptop_name name");
        System.out.println(" SEARCH BY ID           : -gtLaptop_id id");
        System.out.println(" SEARCH BY PRICE        : -gtLaptop_price price");
        System.out.println(" GET LAPTOP < PRICE     : -lstPrice price");
        System.out.println(" GET LAPTOP > PRICE     : -grtPrice price");
        System.out.println(" GET LAPTOP IN RANGE    : -btwPrice price1 price2");
        System.out.println(" GET AVAILABILITY       : -gtAvail ");
        System.out.println(" AVERAGE                : -gtAvg name");
        System.out.println(" SORT BY PRICE          : -sort ");
        System.out.println(" For Help               : -h ");
    }

    public static void print(List<Laptop> a) {
        if (a.isEmpty() == true)
            System.out.println("No Laptops Found");
        else {
            System.out.println("ID\tNAME\tPRICE\tAVAILABILITY\n-----------------------------------");
            a.forEach(System.out::println);
        }
    }

    public static void main(String[] args) throws Exception {
        try {
            BufferedReader reader = new BufferedReader(
                    new FileReader("C:\\Users\\Kusumanjali\\Desktop\\SEM 3\\project\\JavaProject\\laptops.csv"));
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        switch (args[0]) {
        case "-load": {
            try {
                BufferedReader reader = new BufferedReader(
                        new FileReader("C:\\Users\\Kusumanjali\\Desktop\\SEM 3\\project\\JavaProject\\laptops.csv"));
                String laptopLine;
                while ((laptopLine = reader.readLine()) != null) {
                    Create.createLaptop(new Laptop(laptopLine));
                }
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
            break;
        case "-create": {
            int id = Integer.valueOf(args[1]);
            String name = args[2];
            int price = Integer.valueOf(args[3]);
            String availability = args[4];
            Laptop lp = new Laptop(id, name, price, availability);
            Create.createLaptop(lp);
            List<Laptop> allLaptops = GetLaptop.getAllLaptops();
            allLaptops.forEach(System.out::println);
        }
            break;
        case "-printAll": {
            print(GetLaptop.getAllLaptops());
        }
            break;
        case "-update": {
            int id = Integer.valueOf(args[1]);
            String name = args[2];
            int price = Integer.valueOf(args[3]);
            String availability = args[4];
            Laptop c1 = new Laptop(id, name, price, availability);
            Delete.updateLaptop(c1);
            print(GetLaptop.getAllLaptops());
        }
            break;
        case "-delete_id": {
            Delete.deleteLaptop(Integer.valueOf(args[1]));
            print(GetLaptop.getAllLaptops());
        }
            break;
        case "-delete_name": {
            Delete.deleteLaptop(args[1]);
            print(GetLaptop.getAllLaptops());
        }
            break;
        case "-truncate": {
            Delete.DeleteAll();
            System.out.println("Deleted Succesfully");
        }
            break;
        case "-gtLaptop_name": {
            print(GetLaptop.getLaptop(args[1]));
        }
            break;
        case "-gtLaptop_id": {
            print(GetLaptop.getLaptop(Integer.valueOf(args[1])));
        }
            break;

        case "-gtLaptop_price": {
            print(GetLaptop.getLaptopByprice(Integer.valueOf(args[1])));
        }
            break;

        case "-lstPrice": {
            print(Aggregate.getLaptopBypriceLessthan(Integer.valueOf(args[1])));
        }
            break;

        case "-grtPrice": {
            print(Aggregate.getLaptopBypriceGreaterthan(Integer.valueOf(args[1])));
        }
            break;
        case "-btwPrice": {
            print(Aggregate.getLaptopBetweenprice(Integer.valueOf(args[1]), Integer.valueOf(args[2])));
        }
            break;
        case "-gtAvail": {
            print(GetLaptop.getbyAvailability());
        }
            break;
        case "-sort": {
            print(Aggregate.SortByPrice());
        }
            break;
        case "-gtAvg": {
            Aggregate.getAvgPrice(args[1]);
        }
            break;
        case "-h": {
            help();
        }
            break;
        default:
            help();
        }
    }
}