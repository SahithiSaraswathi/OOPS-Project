import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

public class App {
    public static void main(String[] args) {
        try {
            BufferedReader reader = new BufferedReader(
                    new FileReader("C:\\Users\\Kusumanjali\\Desktop\\JavaProject\\laptops.csv"));
            String laptopLine;
            while ((laptopLine = reader.readLine()) != null) {
                System.out.println(laptopLine);
                LaptopDAO.createLaptop(new Laptop(laptopLine));
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Laptop hp = new Laptop(4, "hp", 25000, "no");
        LaptopDAO.updateLaptop(hp);
        Laptop hp1 = new Laptop(5, "hp", 25000, "no");
        LaptopDAO.createLaptop(hp1);
        LaptopDAO.getLaptopByName("mi");
        LaptopDAO.getLaptopByName("hp");
        List<Laptop> allLaptops = LaptopDAO.getAllLaptops();
        allLaptops.forEach(System.out::println);
        System.out.println();
        LaptopDAO.getAllLaptops();
    }
}
