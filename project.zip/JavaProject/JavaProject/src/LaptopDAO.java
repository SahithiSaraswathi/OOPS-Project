import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LaptopDAO {
    // Create
    public static void createLaptop(Laptop lp) {
        Connection con = ConnectionFactory.getConnection();
        final String SQL = "insert into laptop values(?,?,?,?)";
        try (PreparedStatement stm = con.prepareStatement(SQL)) {
            stm.setInt(1, lp.getId());
            stm.setString(2, lp.getName());
            stm.setInt(3, lp.getPrice());
            stm.setString(4, lp.getAvailability());
            int rows_affected = stm.executeUpdate();
            System.out.println(rows_affected + " number of rows created are .");
        } catch (SQLException e) {
            System.out.println("hi");
            e.printStackTrace();
        }
    }

    public static List<Laptop> getAllLaptops() {
        List<Laptop> laptops = new ArrayList<>();
        Connection con = ConnectionFactory.getConnection();
        final String SQL = "select * from laptop";
        try (PreparedStatement stm = con.prepareStatement(SQL)) {
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Laptop lp = new Laptop(rs.getInt("id"), rs.getString("name"), rs.getInt("price"),
                        rs.getString("availability"));
                laptops.add(lp);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return laptops;
    }

    public static List<Laptop> getLaptopByName(String name) {
        List<Laptop> laptops = new ArrayList<>();
        Connection con = ConnectionFactory.getConnection();
        final String SQL = "select * from laptop where name = ?";
        try (PreparedStatement stm = con.prepareStatement(SQL)) {
            stm.setString(1, name);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Laptop lp = new Laptop(rs.getInt("id"), rs.getString("name"), rs.getInt("price"),
                        rs.getString("availability"));
                laptops.add(lp);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println(laptops);
        return laptops;
    }

    public static void updateLaptop(Laptop lp) {
        Connection con = ConnectionFactory.getConnection();
        final String SQL = "update laptop set name=?, price=?,availability=? where id=?";
        try (PreparedStatement stm = con.prepareStatement(SQL)) {
            stm.setInt(4, lp.getId());
            stm.setString(1, lp.getName());
            stm.setInt(2, lp.getPrice());
            stm.setString(3, lp.getAvailability());
            int rows_affected = stm.executeUpdate();
            System.out.println(rows_affected + " number of rows updated are .");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
